# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 17:39:08 2022

@author: norar
"""

import subprocess


#1

def a1():
    host="jetbrains.com"
    otp = subprocess.check_output(["ping",host,"-c 5"])
    print()

#2
def a2():
    host="mytravelyourtravel.com"
    otp = str(subprocess.check_output(["ping",host,"-c 5"]))
    
    salto = otp.find("\\n")
    otp = otp[salto + 2:]
    salto = otp.find("\\n")
    while alto > 0:
        print(otp[:salto])
        otp = otp[salto+2:]
        salto = otp.find("\\n")
    
#extra
    """
    Board
    """
def a3():
    import RPi.GPIO as GPIO
    import time
    
    GPIO.setmode(GPIO.BCM) #modo board (pines 3 y 6) y BCM (pin 18)
    GPIO.setwarnings(False)
    GPIO.setup(18, GPIO.OUT)
    
    for i in range(10):
        print("ON: ", i+1)
        GPIO.output(18, GPIO.HIGH)
        time.sleep(1)
        print("OFF: ", i+1)
        GPIO.output(18, GPIO.LOW)
        
a1()